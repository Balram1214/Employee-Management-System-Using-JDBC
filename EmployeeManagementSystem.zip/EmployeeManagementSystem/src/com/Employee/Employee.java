package com.Employee;

import java.time.LocalDate;

public class Employee {
	int empId;
	String firstName;
	String lastName;
	LocalDate DOB;
	String gender;
	String email;
	long phone_NO;
	String address;
	String position;
	String department;
	LocalDate DOHiring;
	double Salary;
	String nationality;
	String Marital_Status;
	String notice_Period;
	String empType;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDOB() {
		return DOB;
	}

	public void setDOB(LocalDate dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhone_NO() {
		return phone_NO;
	}

	public void setPhone_NO(long phone_NO) {
		this.phone_NO = phone_NO;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public LocalDate getDOHiring() {
		return DOHiring;
	}

	public void setDOHiring(LocalDate dOHiring) {
		DOHiring = dOHiring;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getMarital_Status() {
		return Marital_Status;
	}

	public void setMarital_Status(String marital_Status) {
		Marital_Status = marital_Status;
	}

	public String getNotice_Period() {
		return notice_Period;
	}

	public void setNotice_Period(String notice_Period) {
		this.notice_Period = notice_Period;
	}

	public String getEmpType() {
		return empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public Employee(int empId, String firstName, String lastName, LocalDate dOB, String gender, String email,
			long phone_NO, String address, String position, String department, LocalDate dOHiring, double salary,
			String nationality, String marital_Status, String notice_Period, String empType) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		DOB = dOB;
		this.gender = gender;
		this.email = email;
		this.phone_NO = phone_NO;
		this.address = address;
		this.position = position;
		this.department = department;
		DOHiring = dOHiring;
		Salary = salary;
		this.nationality = nationality;
		Marital_Status = marital_Status;
		this.notice_Period = notice_Period;
		this.empType = empType;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", DOB=" + DOB
				+ ", gender=" + gender + ", email=" + email + ", phone_NO=" + phone_NO + ", address=" + address
				+ ", position=" + position + ", department=" + department + ", DOHiring=" + DOHiring + ", Salary="
				+ Salary + ", nationality=" + nationality + ", Marital_Status=" + Marital_Status + ", notice_Period="
				+ notice_Period + ", empType=" + empType + "]";
	}

}
