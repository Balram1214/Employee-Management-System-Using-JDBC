package com.EmployeeService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.BreakIterator;
import java.time.LocalDate;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthScrollPaneUI;

import com.mysql.cj.protocol.x.SyncFlushDeflaterOutputStream;

public class EmployeeService {

	public static void getAllEmployeeData() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		Statement smt = con.createStatement();
		String sql = "select * from Employee";
		ResultSet rs = smt.executeQuery(sql);
		while (rs.next()) {
			System.out.println("ID: " + rs.getInt("id") + ", FirstName: " + rs.getString("firstName") + ", lastName: "
					+ rs.getString("lastName") + ", DOB: " + rs.getDate("DOB") + ", Gender: " + rs.getString("Gender")
					+ ", Email :" + rs.getString("Email") + ", Phone Number : " + rs.getLong("Phone_No")
					+ ", Address : " + rs.getString("Address") + ", Position : " + rs.getString("Position")
					+ ", Department" + rs.getString("Department") + ", DateOfHiring : " + rs.getDate("Date_Of_Hiring")
					+ ", Salary : " + rs.getDouble("Salary") + ", Nationality : " + rs.getString("Nationality")
					+ ", Marital Status : " + rs.getString("Marital_Status") + ", Notice Period : "
					+ rs.getString("Notice_Period") + ", Employee Type : " + rs.getString("empType"));
		}
		System.out.println("All Data Fetched Successfully!!!!!!!!!!!!!!!!!!!!!!!!!!");

	}

	public static void insertDataIntoEmployee() throws ClassNotFoundException, SQLException {
		try (Scanner sc = new Scanner(System.in)) {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
			String sql = "insert into Employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("Enter values into the table: ");

			System.out.println("Enter Id: ");
			int empId = sc.nextInt();
			System.out.println("Enter firstName: ");
			String firstName = sc.next();
			System.out.println("Enetr lastName: ");
			String lastName = sc.next();
			System.out.println("Enter DOB (YYYY-MM-DD):");
			String DOB = sc.next();
			System.out.println("Enter Gender:");
			String gender = sc.next();
			System.out.println("Enetr email address: ");
			String email = sc.next();
			System.out.println("Enter Phone Number: ");
			long phone_NO = sc.nextLong();
			System.out.println("Enter Address: ");
			sc.nextLine();
			String address = sc.nextLine();
			
			System.out.println("Enter Designation/Position: ");
			sc.next();
			String position = sc.nextLine();
			System.out.println("Enter Department: ");
			String department = sc.next();
			System.out.println("Enter Date Of Hiring:(YY-MM-DD) ");
			String DOHiring = sc.next();
			System.out.println("Enter Salary: ");
			double Salary = sc.nextDouble();
			System.out.println("Enter Nationality: ");
			sc.nextLine();
			String nationality = sc.nextLine();
			System.out.println("Enter Marital Status: ");
			String Marital_Status = sc.next();
			System.out.println("Enter Notice period info(Yes/No): ");
			String notice_Period = sc.next();
			System.out.println("Enter Employee Type(ContractBase/Permenant): ");
			String empType = sc.next();

			ps.setInt(1, empId);
			ps.setString(2, firstName);
			ps.setString(3, lastName);
			ps.setString(4, DOB);
			ps.setString(5, gender);
			ps.setString(6, email);
			ps.setLong(7, phone_NO);
			ps.setString(8, address);
			ps.setString(9, position);
			ps.setString(10, department);
			ps.setString(11, DOHiring);
			ps.setDouble(12, Salary);
			ps.setString(13, nationality);
			ps.setString(14, Marital_Status);
			ps.setString(15, notice_Period);
			ps.setString(16, empType);

			System.out.println("Data Saved Successfully!!!!!!!!!!!!!");
			ps.execute();
			con.close();
			sc.close();
		}

	}

	public static void updateEmployee() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		String sql = "update employee set Salary = ? where Id = ? ";
		PreparedStatement ps = con.prepareStatement(sql);

		System.out.println("Enter Updated Salary: ");
		double salary = sc.nextDouble();

		System.out.println("Enter Id: ");
		int id = sc.nextInt();

		ps.setDouble(12, salary);
		ps.setInt(1, id);

		System.out.println("Data Updated Successfully!!!!!!!!!!!!!!");
		ps.execute();
		con.close();
		sc.close();

	}

	public static void deleteEmployee() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		String sql = "delete from employee where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		System.out.println("Enter Id what you want to delete record: ");
		int id = sc.nextInt();

		ps.setInt(1, id);
		System.out.println("Record Deleted Successfully!!!!!!!!!!!!!!!!!!!!");
		ps.execute();
		con.close();
		sc.close();

	}

	public static void salaryGreaterThan() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		String sql = "select * from employee where salary>=80000";
		Statement smt = con.createStatement();
		smt.execute(sql);
		System.out.println("Record Fetched Successfully whoes salary > 80000");
		con.close();

	}

	public static void fetchITDepartmentData() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		String sql = "select * from employee where Department = IT";
		Statement smt = con.createStatement();
		smt.execute(sql);

		System.out.println("Data Fetched Successfully whoes from IT department");
		con.close();

	}

	public static void fetchEmployeeTypeData() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		// Statement smt = con.createStatement();
		System.out.println(
				"Enter Your Choich which type of employee record you want to get: \n1. Contract Base \n2. Permenant Employees");
		int choich = sc.nextInt();

		switch (choich) {
		case 1:
			String sql = "select * from employee where empType = Contract";
			Statement smt1 = con.createStatement();
			ResultSet rs = smt1.executeQuery(sql);
			smt1.execute(sql);
			while (rs.next()) {
				System.out.println("ID: " + rs.getInt("id") + ", FirstName: " + rs.getString("firstName")
						+ ", lastName: " + rs.getString("lastName") + ", DOB: " + rs.getDate("DOB") + ", Gender: "
						+ rs.getString("Gender") + ", Email :" + rs.getString("Email") + ", Phone Number : "
						+ rs.getLong("Phone_No") + ", Address : " + rs.getString("Address") + ", Position : "
						+ rs.getString("Position") + ", Department" + rs.getString("Department") + ", DateOfHiring : "
						+ rs.getDate("Date_Of_Hiring") + ", Salary : " + rs.getDouble("Salary") + ", Nationality : "
						+ rs.getString("Nationality") + ", Marital Status : " + rs.getString("Marital_Status")
						+ ", Notice Period : " + rs.getString("Notice_Period") + ", Employee Type : "
						+ rs.getString("empType"));
			}
			System.out.println("Contract Base Employee Data Fetched Successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			break;

		case 2:
			String sql1 = "select * from employee where empType = Permanant";
			Statement smt2 = con.createStatement();
			ResultSet rs1 = smt2.executeQuery(sql1);
			smt2.execute(sql1);
			while (rs1.next()) {
				System.out.println("ID: " + rs1.getInt("id") + ", FirstName: " + rs1.getString("firstName")
						+ ", lastName: " + rs1.getString("lastName") + ", DOB: " + rs1.getDate("DOB") + ", Gender: "
						+ rs1.getString("Gender") + ", Email :" + rs1.getString("Email") + ", Phone Number : "
						+ rs1.getLong("Phone_No") + ", Address : " + rs1.getString("Address") + ", Position : "
						+ rs1.getString("Position") + ", Department" + rs1.getString("Department") + ", DateOfHiring : "
						+ rs1.getDate("Date_Of_Hiring") + ", Salary : " + rs1.getDouble("Salary") + ", Nationality : "
						+ rs1.getString("Nationality") + ", Marital Status : " + rs1.getString("Marital_Status")
						+ ", Notice Period : " + rs1.getString("Notice_Period") + ", Employee Type : "
						+ rs1.getString("empType"));
			}
			System.out.println("Permanent Employee Data Fetched Successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			break;

		}
		con.close();
		sc.close();

	}

	public static void fetchNoticePeriodData() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		Statement smt = con.createStatement();
		String sql = "select * from Employee where Notice_Period = 'Yes'";
		ResultSet rs = smt.executeQuery(sql);
		while (rs.next()) {
			System.out.println("ID: " + rs.getInt("id") + ", FirstName: " + rs.getString("firstName") + ", lastName: "
					+ rs.getString("lastName") + ", DOB: " + rs.getDate("DOB") + ", Gender: " + rs.getString("Gender")
					+ ", Email :" + rs.getString("Email") + ", Phone Number : " + rs.getLong("Phone_No")
					+ ", Address : " + rs.getString("Address") + ", Position : " + rs.getString("Position")
					+ ", Department" + rs.getString("Department") + ", DateOfHiring : " + rs.getDate("Date_Of_Hiring")
					+ ", Salary : " + rs.getDouble("Salary") + ", Nationality : " + rs.getString("Nationality")
					+ ", Marital Status : " + rs.getString("Marital_Status") + ", Notice Period : "
					+ rs.getString("Notice_Period") + ", Employee Type : " + rs.getString("empType"));
		}
		System.out.println("Data Fetched Successfully Whoes on Notice Period !!!!!!!!!!!!!!!!!!!!!!!!");

	}

	public static void updateSalaryEmpTypeWise() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		String sql = "update employee set Salary = Salary+5000 where empType = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		System.out.println("Enter Employee Type Contract/Permanant for increase thier Salary: ");
		String empType = sc.next();

		ps.setString(1, empType);
		System.out.println("Record Updated Successfully!!!!!!!!!!!!!!!!!!!!");
		ps.execute();
		con.close();
		sc.close();

	}

	public static void deleteSalaryEmpTypeWise() throws ClassNotFoundException, SQLException {
		// Scanner sc = new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Mydb", "root", "sql@123");
		String sql = "delete from employee where Salary > 100000";
		Statement smt = con.createStatement();
		smt.execute(sql);

		// PreparedStatement ps = con.prepareStatement(sql);
		// System.out.println("Enter Employee Type Contract/Permanant for increase thier
		// Salary: ");
		// String empType = sc.next();

		// ps.setString(1, empType);
		System.out.println("Record Deleted Successfully!!!!!!!!!!!!!!!!!!!!");
		// ps.execute();
		con.close();
		// sc.close();

	}

}
