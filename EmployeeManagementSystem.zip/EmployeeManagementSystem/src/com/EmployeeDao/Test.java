package com.EmployeeDao;

import java.sql.SQLException;
import java.util.Scanner;

import com.EmployeeService.EmployeeService;

public class Test {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		try (Scanner sc = new Scanner(System.in)) {
			System.out.println(
					"Welcome...!\nEnter your choich: \n1. Fetch All Data\n2. Insert Data Into Table\n3. Update Record\n4. Delete Record\n5. Fetch Record whoes Salary > 80000\n6. Fetch Records Whoes Department Is IT\n7. Fetch Records Whoes Contract Base/Permanant\n8. Fetch Records Whoes On Notice Period\n9. Update Salary Whoes On Contract Bases\n10. Delete Record Whoes Salary is > 1 lakh");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				EmployeeService.getAllEmployeeData();
				break;

			case 2:
				EmployeeService.insertDataIntoEmployee();
				break;

			case 3:
				EmployeeService.updateEmployee();
				break;

			case 4:
				EmployeeService.deleteEmployee();
				break;

			case 5:
				EmployeeService.salaryGreaterThan();
				break;

			case 6:
				EmployeeService.fetchITDepartmentData();
				break;

			case 7:
				EmployeeService.fetchEmployeeTypeData();
				break;

			case 8:
				EmployeeService.fetchNoticePeriodData();
				break;

			case 9:
				EmployeeService.updateSalaryEmpTypeWise();
				break;

			case 10:
				EmployeeService.deleteSalaryEmpTypeWise();
				break;

			default:
				System.err.println("Invlid Choice");

			}
		}
	}
}
